#include <cstdio>
#include <cstdlib>
#include "node.h"
#include "individual.h"
#include "population.h"

using namespace std;

extern int genNum ;

Population::Population(int n, int maxdepth, Individual* indiptr):
    size(n), depth(maxdepth) {
    popu = new Individual[size];
}

Population::~Population() {
    // FOR loop delete individuals separately to make safe
    for (int i = 0; i < size; ++i) 
        popu[i].Individual::~Individual();
    indiPtr->~Individual();
    delete indiPtr;
    delete [] idxArray;
}

bool Population::reachBest() {
    float minF = minFitness();
    if (minF < 0.0001) {
        for (int i = 0; i < size; ++i) {
            if (popu[i].fitness == minF)
                printf("Best individual: \n");
            popu[i].Individual::print(popu[i].getNodePtr(), 0);
        }
        return true;
    }
    return false;
}

void Population::newGen(twoIdx winIdx, int cnt) {
    // keep sample elite
    // replace worst population individual with mutated elite

    twoIdx worIdx = maxFitness();
    int fst = worIdx.fst;
    int snd = worIdx.snd;
    
    int winfst = winIdx.fst;
    int winsnd = winIdx.snd;

    // copy elite parent to worst two
    popu[winfst].copy(popu[fst]);
    popu[winsnd].copy(popu[snd]);

    cout << "worst fst: " << fst << endl;
    cout << "worst snd: " << snd << endl;
    cout << "best fst: " << winfst << endl;
    cout << "best snd: " << winsnd << endl;
    cout << "best fst: " << endl;
    popu[winfst].Individual::print(popu[winfst].getNodePtr(), 0);
    cout << "best snd: " << endl;
    popu[winsnd].Individual::print(popu[winsnd].getNodePtr(), 0);
    /*
    cout << "best fst fit: " << popu[winfst].getFitness() << endl;
    cout << "best snd fit: " << popu[winsnd].getFitness() << endl;
    cout << "worst fst fit: " << popu[fst].getFitness() << endl;
    cout << "worst snd fit: " << popu[snd].getFitness() << endl;
    */
    // 2 point crossover two elite parent on place
    mutateCrossOver2Point(winIdx, cnt);
}

void Population::mutateCrossOver2Point(twoIdx winIdx, int cnt) 
{
    int fst = winIdx.fst;
    int snd = winIdx.snd;
    int fstSize = popu[fst].getSize(); 
    int sndSize = popu[snd].getSize();
    int one = rand() % fstSize;
    int two = rand() % sndSize;
    while (one == two && (one == 0 || two == 0))
        two = rand() % sndSize;
    cout << "one val: " << one << endl;
    cout << "two val: " << two << endl;

    node* oneprv;
    node* onecur;
    node* twoprv;
    node*twocur;
    twoPtr pone, ptwo;
    int onematch = -1, twomatch = -1;
    int p = 0, q = 0;
    
    cout << "one: " << endl;
    pone = popu[fst].myTraverse(popu[fst].the_indiv, one, onematch, p);
    cout << "two: " << endl;
    ptwo = popu[snd].myTraverse(popu[snd].the_indiv, two, twomatch, q);

    oneprv = pone.prt;
    onecur = pone.cld;
    twoprv = ptwo.prt;
    twocur = ptwo.cld;
    cout << "oneprv: " << oneprv << endl;
    cout << "onecur: " << onecur << endl;
    cout << "twoprv: " << twoprv << endl;
    cout << "twocur: " << twocur << endl;
    
    // swap two parts of subtrees from two individuals
    // special conditions still needs to be worked on
    for (int i = 0; i < MAX_ARITY; ++i) 
    {
        if (oneprv && oneprv->branches[i] == onecur) 
        {
            oneprv->branches[i] = twocur;
            twocur->parent = oneprv;
        }
        if (!oneprv && onecur) 
        {
            popu[fst].the_indiv->erase();
            popu[fst].the_indiv = NULL;
            popu[fst].copy(twocur);
            (popu[fst].the_indiv)->parent = NULL;
        }
        
        if (twoprv && twoprv->branches[i] == twocur)
        {
            twoprv->branches[i] = onecur;
            onecur->parent = twoprv;
        }
    }
    cout << "best fst after swap: " << endl;
    popu[fst].Individual::print(popu[fst].getNodePtr(), 0);
    cout << "best snd after swap: " << endl;
    popu[snd].Individual::print(popu[snd].getNodePtr(), 0);

    /*
    float delta, tempval;
    if (cnt % 2 == 0)  
        genNum *= 10.0;    

    // mutate both crossoved parent with mutrate
    float lowThd, highThd;
    lowThd = (*(popu[0].funPtr)).low;
    highThd = (*(popu[0].funPtr)).high;
        
    // fst parent mutate
    for (int i = 0; i < p; ++i) {
        if (rand()%1000/1000.0 < mutRate) 
        {
            delta = (float)((highThd - lowThd) / genNum );
            
            if ( (rand()%100/100.0) < 0.5)   // pos
                tempval = popu[fst].point[i] + delta;
            else                  // neg
                tempval = popu[fst].point[i] - delta;
            while (tempval < lowThd || tempval > highThd) {
                delta = (float)(highThd - lowThd) / genNum;
                if ( (rand()%100/100.0) < 0.5)   // pos
                    tempval = popu[fst].point[i] + delta;
                else                  // neg
                    tempval = popu[fst].point[i] - delta;
            } // while
        }
        popu[fst].point[i] = tempval;
    }
    popu[fst].fitness = popu[fst].getFitness();
    
    for (int i = 0; i < p; ++i) {
        if (rand()%1000/1000.0 < mutRate) 
        {
            delta = (float)((highThd - lowThd) / genNum );
            if ( (rand()%100/100.0) < 0.5)   // pos
                tempval = popu[snd].point[i] + delta;
            else                  // neg
                tempval = popu[snd].point[i] - delta;
            while (tempval < lowThd || tempval > highThd) {
                    printf("I got here 307\n");

                delta = (float)(highThd - lowThd) / genNum;
                if ( (rand()%100/100.0) < 0.5)   // pos
                    tempval = popu[snd].point[i] + delta;
                else                  // neg
                    tempval = popu[snd].point[i] - delta;
            } // while
        }
        popu[snd].point[i] = tempval;
    }
    popu[snd].fitness = popu[snd].Individual::getFitness();
    */
}

twoIdx Population::tourSelection(int len) {
    twoIdx idx;
    int winIdx = idxArray[0], sndIdx = winIdx;
    float winFitness = popu[winIdx].fitness, sndFitness = winFitness;
    
    int temp = idxArray[0], snd;
    float tempFitness = popu[temp].fitness, sndfit;

    for (int i = 1; i < len; ++i) {
        snd = temp;
        sndfit = tempFitness;
        temp = idxArray[i];
        tempFitness = popu[temp].fitness;
        
        if (tempFitness-winFitness < 0.000001) {        
            sndFitness = winFitness;
            sndIdx = winIdx;
            winFitness = tempFitness;
            winIdx = temp;
        }
        
        if ( (tempFitness-winFitness>0.000001) && (sndFitness-tempFitness>0.000001) ) {
            sndFitness = tempFitness;
            sndIdx = temp;
        }
    }
    
    idx.fst = winIdx;
    idx.snd = sndIdx;
    cout << "tour fst: " << winIdx << endl;
    cout << "tour snd: " << sndIdx << endl;
    
    return idx;
}

void Population::print() {  // print population
    for (int i = 0; i < size; ++i) 
    {
        cout << endl << "popu[" << i << "]: " << " Size: " << popu[i].getSize() << endl;
        popu[i].Individual::print(popu[i].getNodePtr(), 0);
    }
    printf("\n\n");
}

void Population::generate() { // generate population
    int dep;
    for (int i = 0; i < size; ++i)
    {
        dep = rand() % depth + 1;
        cout << "popu[" << i << "] " << "dep: " << dep << endl;
        popu[i].Individual::generate(dep);
        popu[i].fitness = popu[i].getFitness();
    }
}

void Population::printRanIndi(int len) {
    for (int i = 0; i < len; ++i)
	printf("%d ", idxArray[i]);
    printf("\n");
}

void Population::genRanIndi(int n) {
    idxArray = new int[n];
    idxArray[0] = rand() % size;
    for (int i = 1; i < n; ++i) 
    {
        idxArray[i] = rand() % size;
        while (idxArray[i] == idxArray[i-1])
            idxArray[i] = rand() % size;
    }
}

float Population::minFitness() {
    float minFitness = popu[0].fitness;
    float tempFitness;
    for (int i = 1; i < size; ++i) {
	tempFitness = popu[i].fitness;
	if (tempFitness < minFitness)
	    minFitness = tempFitness;
    }
    return minFitness;
}

twoIdx Population::maxFitness() {
    twoIdx idx;
    float maxFitness = popu[0].fitness, sndFitness;
    int worIdx = 0, sndIdx, temp = 0, snd;
    float tempFitness = popu[temp].fitness, sndfit;

    for (int i = 1; i < size; ++i) {
        snd = temp;
        sndfit = tempFitness;        
        temp = i;
        tempFitness = popu[i].fitness;
        
        if (tempFitness - maxFitness > 0.00001) {
            sndFitness = maxFitness;
            sndIdx = worIdx;
            maxFitness = tempFitness;
            worIdx = temp;
        } else if ( (tempFitness - maxFitness <= 0.00001) && (tempFitness - sndFitness > 0.00001) ) {
            sndFitness = tempFitness;
            sndIdx = i;
        }
    }
    idx.fst = worIdx;
    idx.snd = sndIdx;
    return idx;
}

float Population::avgFitness() {
    float avgFitness = 0.0;
    for (int i = 0; i < size; ++i) {
        avgFitness += popu[i].fitness;
    }
    avgFitness = (float) (avgFitness / size);
    return avgFitness;
}

float Population::avgIndiSize() {
    int res = 0;
    for (int i = 0; i < size; ++i) 
        res += popu[i].getSize();
    float avgSize = (float)res/size;
    return avgSize;
}

void Population::evaluate_print() {
    for (int i = 0; i < size; ++i)
        popu[i].evaluate_print();
}

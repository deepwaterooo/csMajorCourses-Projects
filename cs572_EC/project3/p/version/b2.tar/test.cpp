#include<iostream>
#include<cmath>
#include<ctime>
#include<cstdlib>
#include "node.h"
#include "individual.h"
#include "population.h"

using namespace std;

// g++ -g test.cpp individual.cpp population.cpp node.cpp

double X;

int main(){
	srand(time(NULL));
	Individual i;
    int maxDepth = 3;

    // test if copy is successful
    i.generate(maxDepth);
    i.print(i.getNodePtr(), 0);
	i.evaluate_print();
    i.calc_size();
	cout << "i Size = " << i.getSize() << endl;
    /*
    cout << endl << endl << "Individual j copied from i: " << endl;
    Individual j = i.copy();
    j.print(j.getNodePtr(), 0);
    j.evaluate_print();
    j.calc_size();
    cout << "Size = " << j.getSize() << endl;
    */

    Individual* indi = &i;
    int popuSize = 100;
    float mutateRate = 0.3;
    float crsRate = 0.9;

    Population* popu = new Population(popuSize, maxDepth, indi, mutateRate);
    popu->generate();

    cout << endl << endl << "Printing population: " << endl;
    popu->print();
    cout << endl;
    //popu->evaluate_print();

    cout << "Population Information: " << endl;
    cout << "min:" << popu->minFitness() << endl;
    cout << "avg:" << popu->avgFitness() << endl;
    cout << "avgSize:" << popu->avgIndiSize() << endl;

    int sampleSize = 10;
    int counter = 0;
    int* idxArray = new int[sampleSize];
    twoIdx winIdx;

    while (counter < 100) {
        //while (popu->minFitness() - 2.5 > 0.00001) {     
        popu->genRanIndi(sampleSize);
        idxArray = popu->idxArray;
        popu->printRanIndi(sampleSize);
        winIdx = popu->tourSelection(sampleSize);
        popu->newGen(winIdx, counter);
        ++counter;

        if (counter % 10 == 0)
            cout << counter << "\t" << popu->minFitness() << "\t" << popu->avgFitness() << endl;                 
    }

    float tmp = popu->minFitness();
    //int index;
    //pf("tmp", tmp);

}

// pf.h

#ifndef PH_H
#define PH_H

#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std;

void pf(string s, double x);

#endif

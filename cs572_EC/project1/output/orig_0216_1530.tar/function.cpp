#include <iostream>
#include "fitness.h"
#include "function.h"

Function::Function(float l, float h, funPtrSep  ptr, bool flag):
    low(l), high(h), fitness(0.0), sepaFlag(flag), sepPtr(ptr)
{
    printf("Function Constructor funPtrSep: i got here, Constructor\n");
}

Function::Function(float l, float h, funPtrNSe  ptr, bool flag):
    low(l), high(h), fitness(0.0), sepaFlag(flag), nsePtr(ptr)
{
    printf("Function Constructor funPtrNSe: i got here, Constructor\n");
}

Function::Function(const Function& orig):
    low(orig.low),
    high(orig.high),
    fitness(orig.fitness),
    sepaFlag(orig.sepaFlag),
    sepPtr(orig.sepPtr),
    nsePtr(orig.nsePtr)
{
}

Function::~Function() 
{
    //delete sepPtr;
    //delete nsePtr;
}

float Function::getFitness(float x) 
{
    fitness = (*sepPtr)(x);
    return fitness;
}

float Function::getFitness(float* x, int p) 
{
    //pf("Function::getFitness A", 0);
    fitness = (*nsePtr)(x, p);
    //pf("Function::getFitness B", 0);
    return fitness;
}

#ifndef POPULATION_H
#define POPULATION_H

#include <iostream>
#include "fitness.h"
#include "function.h"
#include "individual.h"

using namespace std;

class Population: public Individual {
 public:
    Population(float l, float h, funPtrSep ptr, bool flag, int n, float mutRate);
    Population(float l, float h, funPtrNSe ptr, bool flag, int n, float mutRate);
    Population(int n, float mutRate, Individual* indiptr);
    
    //Population(const Population&);
    //virtual Population& operator=(const Population&);
    virtual Population& operator=(Population&);
    
    //~Population();
    virtual ~Population();
    
    // functions
    int getSize();  // get population size
    void print();   // print population
    void generate();// generate population
    //void mutate(float mutRate);
    //void mutateAll();

    void genRanIndi(int n);
    void printRanIndi(int len);
    int tourSelection(int len);

    float minFitness();
    int maxFitness();
    float avgFitness();
    int roulSelection();

    void newGen(int winIdx, int cnt);
    bool reachBest();    

    int* idxArray;
 private:
    //static genNum = 10;
    int size;
    //int genCnt;
    float mutRate;
    Individual* popu;
};

#endif

#include <iostream>
#include <cstdio>
#include "fitness.h"
#include "function.h"
#include "individual.h"
#include "population.h"

using namespace std;

typedef float (*funPtrSep)(float);
typedef float (*funPtrNSe)(float*, int);

// g++ -g main.cpp individual.cpp population.cpp fitness.cpp function.cpp -o a

// funPtrNSe set

int main() 
{
    funPtrNSe pFun[3] = {        
        getRosFitness,    
        getAckFitness,
        getGriFitness
    };
    funPtrNSe pfun;
    Function* funptr;

    int i = 1;
    
    pfun = pFun[i];

    //funptr = new Function(rosl, rosh, pFun[0], false);  // slow 2750,000 520,000 > 0.00233
    funptr = new Function(ackl, ackh, pFun[1], false);   // fast 61000  1000 100 0.5
    //funptr = new Function(gril, grih, pFun[2], false);    // fast 51000; 30000 10000 10
    
     Individual* indi = new Individual(funptr);
     indi->generate();
     //indi->print();

     int popuSize = 100;
     float mutateRate = 0.25;
     float crsRate = 0.8;

     Population* popu = new Population(popuSize, mutateRate, crsRate, indi);
     //Population* popu = new Population(popuSize, mutateRate, indi);

     
     int sampleSize = 10;
     int counter = 0;
     int* idxArray = new int[sampleSize];
     //int winIdx;
     twoIdx winIdx;

     while (counter < 1000) {
         popu->genRanIndi(sampleSize);
         idxArray = popu->idxArray;
         //popu->printRanIndi(sampleSize);
    
         winIdx = popu->tourSelection(sampleSize);

         popu->newGen(winIdx, counter);
         ++counter;

         if (counter % 100 == 0)
             printf("%d\t%4.5f\t%4.5f\n", counter, popu->minFitness(), popu->avgFitness());
     }
    
     popu->minFitness();
     printf("number of loops have conducted: %d\n", counter);
    
     delete idxArray;
     delete funptr;
     return 0;    
}

// funPtrSep set
/*
int main() {
    funPtrSep pFun[3] = {        
        getSphFitness,
        getRasFitness,
        getSchFitness
    };
    funPtrSep pfun;
    Function* funptr;

    int i = 2;  //xall pass
    
    pfun = pFun[i];

    //funptr = new Function(sphl, sphh, pFun[0], true);  // 32,000    slightly slow
    //funptr = new Function(rasl, rash, pFun[1], true);// 100 500,000 specifalGen.5 1600,000 .00001
    funptr = new Function(schl, schh, pFun[2], true); // 100 1000,000 specialGen 3000,000 0.00086
    
    float x = funptr->getFitness(0.50);
    
     Individual* indi = new Individual(funptr);
     indi->generate();
     indi->print();
     pf("indi fitness", indi->fitness);

     int popuSize = 100;
     float mutateRate = 0.5;
     float crsRate = 0.8;

     Population* popu = new Population(popuSize, mutateRate, crsRate, indi);

     int sampleSize = 10;
     int counter = 0;
     int* idxArray = new int[sampleSize];
     twoIdx winIdx;

     while (counter < 1000) {
         popu->genRanIndi(sampleSize);
         idxArray = popu->idxArray;
         //popu->printRanIndi(sampleSize);
    
         winIdx = popu->tourSelection(sampleSize);

         popu->newGen(winIdx, counter);
         ++counter;

         if (counter % 100 == 0)
             printf("%d\t%4.5f\t%4.5f\n", counter, popu->minFitness(), popu->avgFitness());
     }
    
     popu->minFitness();
     printf("number of loops have conducted: %d\n", counter);
    
     delete idxArray;
     delete funptr;
     return 0;    
}

*/
